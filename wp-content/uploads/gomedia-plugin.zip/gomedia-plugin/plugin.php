<?php
/*
Plugin Name: GoMedia Support
Plugin URI: http://www.videousermanuals/
Description:  The GoMedia plugin adds a support widget to your WordPress Dashboard. See also: <a href="http://gomedia.com.au/supportportal/">GoMedia Support</a> for further support.
Version: 1.3.2
Author: www.videousermanuals.com
Author URI: http://www.videousermanuals.com
*/

// WP Admin Menu

function wpm_add_pages() {
	 add_menu_page('GoMedia Help', 'GoMedia Help', 0, __FILE__, 'wpm_toplevel_page', plugins_url('gomedia-plugin/images/vum-logo.png'),'3.127453' );
	 add_submenu_page(__FILE__, 'Videos', 'Videos', 0, __FILE__, 'wpm_toplevel_page');
	 add_submenu_page(__FILE__, 'User Manual', 'User Manual', 0, 'online-manual', 'wpm_online_manual');   
	 #$wpm_administration = add_submenu_page(__FILE__, 'Manual Options', 'Manual Options', 10, 'manual-options', 'wpm_admin');	 


	$wpm_help = "
	<style>
	ul.help_list {
		margin-top:10px;}
		
	ul.help_list li {
		list-style-type:disc;
		margin-left:20px;}
	</style>
		
	<p>For more details of how to use this plugin please refer to our FAQ section.  <a href=\"http://www.videousermanuals.com/faq/\">http://www.videousermanuals.com/faq/</a></p>
	
	<p>In order to use this plugin, you must have a serial number, which should have been emailed to you when you first subscribed to the plugin.</p>
	
	<p>If you have any issues with the plugin, please put in a support ticket: <a href=\"http://www.videousermanuals.com/support-desk/\">http://www.videousermanuals.com/support-desk/</a>.</p>
	
	<p style=\"font-size:9px; margin-bottom:10px;\">Icons: <a href=\"http://www.woothemes.com/2009/09/woofunction/\">WooFunction</a></p>	
	
	<p>Please note the links below are not actually related to this plugin (we could not figure out how to remove them. If anyone knows how to, please let us know!)</p>
	";
	
	add_contextual_help($wpm_administration, $wpm_help);

}
add_action('admin_menu', 'wpm_add_pages');

// Include Subpages
include('videos.php');
include('manual.php');
include('admin-page.php');

function showMessage($message, $errormsg = false)
{
	if ($errormsg) {
		echo '<div id="message" class="error">';
	}
	else {
		echo '<div id="message" class="updated fade gomedia-message" >';
	}

	echo "<h4><strong>$message</strong></h4></div>";
} 

function showAdminMessages()
{
       showMessage('<div class="gomedia-message-text">Hi! How exciting.. lets get started with your new website </div><div class="gomedia-message-buttam"><a href="' . get_option( 'siteurl' ) . '/wp-admin/admin.php?page=gomedia-plugin/plugin.php" class="gomedia-message-button">Start Here!!</a></div><div style="clear:both;"></div>');
}

add_action('admin_notices', 'showAdminMessages');



function help_status_init() {
    // disable help bar
	if(get_option("help_status") == "1"){
    	remove_action( 'admin_notices', 'showAdminMessages');
    }            
}    
 
add_action('init', 'help_status_init' );

if ('saveDB' == $_POST['action']) {
	update_option("help_status",$_POST['help_status']);
}

add_option("help_status","");

?>